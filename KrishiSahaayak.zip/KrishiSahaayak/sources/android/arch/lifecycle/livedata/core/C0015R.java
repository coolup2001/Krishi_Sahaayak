package android.arch.lifecycle.livedata.core;

/* renamed from: android.arch.lifecycle.livedata.core.R */
public final class C0015R {
}
