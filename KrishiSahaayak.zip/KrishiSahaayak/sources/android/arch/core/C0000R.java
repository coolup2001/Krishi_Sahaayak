package android.arch.core;

/* renamed from: android.arch.core.R */
public final class C0000R {
}
